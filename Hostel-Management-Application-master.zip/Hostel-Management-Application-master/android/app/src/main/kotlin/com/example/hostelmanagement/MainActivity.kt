package com.example.hostelmanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
